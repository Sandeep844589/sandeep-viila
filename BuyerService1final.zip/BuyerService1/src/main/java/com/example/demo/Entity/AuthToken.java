package com.example.demo.Entity;

public class AuthToken {

    private String token;
    private String username;
    private int buyerid;

    public AuthToken(){

    }

  

    @Override
	public String toString() {
		return "AuthToken [token=" + token + ", username=" + username + ", buyerid=" + buyerid + "]";
	}



	public int getBuyerid() {
		return buyerid;
	}



	public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}



	public AuthToken(String token, String username, int buyerid) {
		super();
		this.token = token;
		this.username = username;
		this.buyerid = buyerid;
	}



	public AuthToken(String token){
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
