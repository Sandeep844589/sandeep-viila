package com.example.demo.repositry;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.PurchaseHistory;

@Repository
public interface PurchaseHistoryDao extends JpaRepository<PurchaseHistory, Integer>{
	 @Query(value="SELECT * FROM purchase_history WHERE purchase_history.user_buyerid = :buryid" ,nativeQuery = true)
	List<PurchaseHistory> findByBuerid(@Param("buryid")int burid);

}
