package com.example.demo.repositry;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.Buyer;
//import com.example.demo.Entity.Product;
@Repository
public interface UserDao extends JpaRepository<Buyer, Integer>
{

	Buyer findByusername(String username);

}
