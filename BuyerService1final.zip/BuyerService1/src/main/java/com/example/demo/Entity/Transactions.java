package com.example.demo.Entity;



import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;

//import com.fasterxml.jackson.annotation.JacksonAnnotation;

//import org.hibernate.annotations.ManyToAny;

@Entity
public class Transactions {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionid;
	/*@ManyToOne//user_id
	private Buyer user;*/
	//seller_id

	private int buyerid;
	
	private String transactiontype;//(Eg. debit or credit)
	@CreationTimestamp
	@Temporal(TemporalType.DATE)
	private Date date_time;

	private float tatal_price;
	public Transactions()
	{
		System.out.println("Transation Object has been created");
	}

	
public Transactions(int transactionid, int buyerid, String transactiontype, Date date_time, float tatal_price) {
		super();
		this.transactionid = transactionid;
		this.buyerid = buyerid;
		this.transactiontype = transactiontype;
		this.date_time = date_time;
		this.tatal_price = tatal_price;
	}


public int getBuyerid() {
		return buyerid;
	}


public void setBuyerid(int buyerid) {
		this.buyerid = buyerid;
	}

public float getTatal_price() {
	return tatal_price;
}


public void setTatal_price(float tatal_price) {
	this.tatal_price = tatal_price;
}


	@Override
public String toString() {
	return "Transactions [transactionid=" + transactionid + ", buyerid=" + buyerid + ", transactiontype="
			+ transactiontype + ", date_time=" + date_time + ", tatal_price=" + tatal_price + "]";
}

public int getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}
	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
    public Date getDate_time() {
		return date_time;
	}

	public void setDate_time(Date date_time) {
		this.date_time = date_time;
	}
	
	

}
