export class Product
{
    productid:number;
     productName: String
	 Manufacturer: String
     Model:String
		//sellerId: 23

		sdetails:number;
		 price:number;
		quantity:number;
		
		
	 decription:String;
}