import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayCartItemsComponent } from './display-cart-items/display-cart-items.component';
import { SearchProductsComponent } from './search-products/search-products.component';


const routes: Routes = [
  {path:'DisplayCart',component: DisplayCartItemsComponent },
  {path:'SearchProducts',component: SearchProductsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
