import { Component } from '@angular/core';
import { BuyerServiceService } from './buyer-service.service';
import { Product } from './Product';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'BuyerPart';

  constructor() { }
  ngOnInit(){
    
  } 
    
}
