import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayCartItemsComponent } from './display-cart-items/display-cart-items.component';
import { SearchProductsComponent } from './search-products/search-products.component';
import { SigninComponent } from './signin/signin.component';
import { HomeComponent } from './home/home.component';
import { SignupComponent } from './signup/signup.component';


const routes: Routes = [
  {path:'Home/DisplayCart',component: DisplayCartItemsComponent },
  {path:'Home/SearchProducts',component: SearchProductsComponent },
  {path:'Home',component: HomeComponent  },
  {path:'signin',component: SigninComponent },
  {path:'signup',component: SignupComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
