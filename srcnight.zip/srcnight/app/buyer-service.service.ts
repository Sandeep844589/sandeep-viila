import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Product } from './Product';
import { Cart } from './Shoopingcart';
import { Transactions } from './Transaction';
@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  
  
  
  
  private baseUrl="http://localhost:8081/Product/viewAllProducts";
  private baseUrl1="http://localhost:8080/buyer";
  constructor(private http:HttpClient ) { }
  getProductByName(productName: String) :Observable<any> {
    return this.http.get(`${this.baseUrl}/${productName}`);
  }
  addCart(cart:object):Observable<any> {
    console.log("ejfhw");
    console.log(cart);
   return  this.http.post(`${this.baseUrl1}`+`/addCart/1`,cart);
  }
  displayCartItems() :Observable<any>{
    return this.http.get(`${this.baseUrl1}`+`/getcartitems`);
  }
  updateCartItems(incart:Cart):Observable<any> {
    console.log("jfshjsg");
    console.log(incart);
   return this.http.post(`${this.baseUrl1}`+`/updatecart/1`,incart);
  }
  
  
  checkOutCart(transactuin: Transactions):Observable<any> {
    return this.http.post(`http://localhost:8080/Cart/checkout/1`,transactuin);
  }

  
}
