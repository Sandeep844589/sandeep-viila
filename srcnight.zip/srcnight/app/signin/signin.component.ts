import { Component, OnInit } from '@angular/core';
import { Buyer } from '../Buyer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  username:string;
  password:string;
  buyer:Buyer=new Buyer();
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit() {
    console.log(this.buyer.username);
    console.log(this.buyer.password);
   
      if(this.buyer.username=="SandeepVilla" && this.buyer.password=="Sandy1998")
      {
        alert("You have Successfully registerd"+" Hii"+" "+this.buyer.username);
        this.router.navigate(['Home']);
      }
    }

}
