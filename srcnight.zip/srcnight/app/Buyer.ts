export class Buyer
{
   // buyerid:number;
	username:String;
	 password:String;
	emailid:String;
 mobile_number:number;
}