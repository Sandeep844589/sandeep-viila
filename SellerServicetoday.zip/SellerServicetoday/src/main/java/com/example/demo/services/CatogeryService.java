package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Category;
import com.example.demo.repositry.CatogeryDao;
@Service
public class CatogeryService implements ICatogeryService {
@Autowired
private CatogeryDao catogerydao;
	@Override
	public List<Category> getAllCatogeris() {
		
		return catogerydao.findAll();
	}

}
