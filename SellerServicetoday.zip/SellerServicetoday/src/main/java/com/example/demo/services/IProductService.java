package com.example.demo.services;

import java.util.List;
import java.util.Optional;

//import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.ProductDetails;

@Service
public interface IProductService {

	ProductDetails addProduct(int sellerid, ProductDetails prodetails, int subcatogeryid);

	void deleteProduct(int prodid, int sellerid);

	void updateProduct(ProductDetails pdetails, int sellerid, int prodid);

	List<ProductDetails> viewAllProducts(int sellerid, String productname);

	Optional<ProductDetails> getProductDetails(int productid);

	List<ProductDetails> viewAllProductsname(String productname);

}
