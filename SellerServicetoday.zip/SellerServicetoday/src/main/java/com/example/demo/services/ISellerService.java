package com.example.demo.services;

import org.springframework.stereotype.Service;

import com.example.demo.Entity.SellerDetails;
@Service
public interface ISellerService {

	String createSeller(SellerDetails sdetails);

	String updateSeller(Integer sellerid, SellerDetails sdetails);

	SellerDetails findOne(String username);

}
