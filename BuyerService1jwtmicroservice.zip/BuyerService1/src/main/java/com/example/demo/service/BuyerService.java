package com.example.demo.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Buyer;

import com.example.demo.Entity.Shoppingcart;
//import com.example.demo.Transactions;
//import com.example.demo.Entity.Product;
//import com.example.demo.repositry.BuyerDao;
import com.example.demo.repositry.CartDao;
import com.example.demo.repositry.UserDao;


@Service(value = "BuyerService")
public class BuyerService implements  UserDetailsService {
	//@Autowired
	//public BuyerDao bydao;
	@Autowired
	public UserDao usdao;
	@Autowired
	public CartDao cdao;
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Buyer user = usdao.findByusername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	/*public List<Product> getProducts()
	{
		
		return  bydao.findAll();
	}
*/
	public Buyer addBuyer(Buyer buyer) {
		// TODO Auto-generated method stub
		String pass=bcryptEncoder.encode(buyer.getPassword());
		buyer.setPassword(pass);
		
		 
		return usdao.save( buyer); 
	}

	public List<Buyer> getUsers() {
		// TODO Auto-generated method stub
		return usdao.findAll();
	}

	public String addCart(int buyerid, Shoppingcart scart) {
		Buyer br =usdao.getOne(buyerid);
		System.out.println(br);
		scart.setUser(br);
		// TODO Auto-generated method stub
		System.out.println(scart);
		cdao.save(scart);
		return "\" Item Added To Cart\" ";
	}

	public List<Shoppingcart> cartItems() {
		// TODO Auto-generated method stub
		return cdao.findAll();
	}

	public String deleteCartItem(Integer productid) {
		// TODO Auto-generated method stub
		 cdao.deleteBypId(productid);
		return "\"item deleted in the cart\" ";  
	}

	public Shoppingcart updateCart(Shoppingcart scart1,int buid) 
	{
		Buyer br1=usdao.getOne(buid);
		Shoppingcart sr=cdao.getOne(scart1.getCart_Id());
		//int cartid=scart1.getCart_Id();
		int prid=scart1.getProductid();
		int quantity=scart1.getQuantity();
		float price=scart1.getPrice();
		float toatlprice=scart1.getTotalprice();
		//sr.setCart_Id(cartid);
		sr.setProductid(prid);
		sr.setQuantity(quantity);
		sr.setPrice(price);
		sr.setTotalprice(toatlprice);
		sr.setUser(br1);
		System.out.println(sr);
		
		return cdao.saveAndFlush(sr);
	}

	public String deleteAll() {
		cdao.deleteAll();
		return "\"Caert Items Deleted\"";
	}

	public Buyer findOne(String username) {
		// TODO Auto-generated method stub
		return usdao.findByusername(username);
	}

	
	

}
