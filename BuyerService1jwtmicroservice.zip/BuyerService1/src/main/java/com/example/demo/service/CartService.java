package com.example.demo.service;

import java.util.List;

//import java.util.Date;
//import java.util.List;

//import javax.persistence.Temporal;
//import javax.persistence.TemporalType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Buyer;
import com.example.demo.Entity.PurchaseHistory;
import com.example.demo.Entity.Shoppingcart;
import com.example.demo.Entity.Transactions;
//import com.example.demo.repositry.BuyerDao;
import com.example.demo.repositry.CartDao;
import com.example.demo.repositry.PurchaseHistoryDao;
import com.example.demo.repositry.TransactionDao;
import com.example.demo.repositry.UserDao;

@Service
public class CartService {
	/*@Autowired
	public BuyerDao bydao;*/
	@Autowired
	public UserDao usdao;
	@Autowired
	public CartDao cdao;
	@Autowired
	public TransactionDao tdao;
	@Autowired
	public PurchaseHistoryDao pdao;
	
	public Transactions checkOut(Transactions transac, int buid) {
		Buyer buyr=usdao.getOne(buid);
		System.out.println(buyr);
		transac.setBuyerid(buid);  
		System.out.println(transac);
		float sum=0;
		
		//PurchaseHistory phistory=new PurchaseHistory();
		//Shoppingcart shcartitems=new Shoppingcart();
		List<Shoppingcart> shcart1=cdao.byid(buid);
		System.out.println(shcart1);
		for(int i=0;i<shcart1.size();i++)
		{
			PurchaseHistory phistory=new PurchaseHistory();
			Shoppingcart shcartitems=shcart1.get(i);
			int size=shcartitems.getQuantity();
			float cost=shcartitems.getTotalprice();
			
			//phistory.setPurchase_Id(i);
			phistory.setNumber_of_items(size);
			phistory.setUser(buyr);
			phistory.setProductprice(cost);
			System.out.println(shcartitems);
			System.out.println("hii"+shcartitems.getCart_Id());
	        cdao.deleteById(shcartitems.getCart_Id());
			pdao.save(phistory);
			//float sum=0;
			sum=cost+sum;
			//sum1=sum;
		}
		transac.setTatal_price(sum);
		Transactions tr=tdao.save(transac);
		System.out.println("This is transactionnf"+tr);
		
		// TODO Auto-generated method stub
		return tr;
	}

	public void deleteByItemId(int burid) {
		
		 cdao.deleteByItemId(burid);
	}

	public String addPurchase(PurchaseHistory phis) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Transactions> getAllTransactions() {
		// TODO Auto-generated method stub
		return tdao.findAll();
	}

	public List<PurchaseHistory> gelAllPurchaseHistory(int burid) {
		// TODO Auto-generated method stub
		return pdao.findByBuerid(burid);
	}

	
	

}
