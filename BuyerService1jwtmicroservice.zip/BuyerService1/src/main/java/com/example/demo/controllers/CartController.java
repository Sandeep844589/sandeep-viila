package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

//import javax.transaction.Transaction;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.PurchaseHistory;
import com.example.demo.Entity.Transactions;
import com.example.demo.service.BuyerService;
import com.example.demo.service.CartService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/Cart")
public class CartController {
	@Autowired
	public BuyerService buyerserv;
	@Autowired
	public CartService cartserv;
	@PostMapping("/checkout/{bids}")
	public Transactions checkOut(@RequestBody Transactions transac,@PathVariable("bids") int buid)
	{
		return cartserv.checkOut(transac,buid);
	}
	@DeleteMapping("/deletecartitembyid/{id}")
	public String deleteByItemId(@PathVariable("id") int burid)
	{
		 cartserv.deleteByItemId(burid);
		 return "Items Deleted by BuerId";
	}
	@PostMapping("/addPurchasehistory")
	public String addPurchase(@RequestBody PurchaseHistory phis)
	{
		return cartserv.addPurchase(phis);
	}
	@GetMapping("/getalltransactions")
	public List<Transactions> gelAllTransactions()
	{
		return cartserv.getAllTransactions();
	}
	@GetMapping("/getallHistory/{burid}")
	public List<PurchaseHistory> gelAllPurchaseHistory(@PathVariable("burid") int burid)
	{
		return cartserv.gelAllPurchaseHistory(burid);
	}
	

}
