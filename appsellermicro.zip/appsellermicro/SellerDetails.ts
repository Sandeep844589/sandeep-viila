export class Seller
{
    username:String;
    password:String;
    emailid:String;
   
 gstin:number;
	 companydescription:String;
	postal_address:String
	 website:String
	 companyname:String
	 contact_number:number;
}