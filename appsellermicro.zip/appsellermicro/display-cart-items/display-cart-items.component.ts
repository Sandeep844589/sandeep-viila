import { Component, OnInit } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { Cart, ShopCart } from '../Shoopingcart';
import { Transactions } from '../Transaction';

@Component({
  selector: 'app-display-cart-items',
  templateUrl: './display-cart-items.component.html',
  styleUrls: ['./display-cart-items.component.css']
})
export class DisplayCartItemsComponent implements OnInit {
  disCart:ShopCart[];
  shcart:ShopCart =new ShopCart();
  fare:number;
  totalAmount:number;
  transac:Transactions =new Transactions();
  constructor(private displaycart:BuyerServiceService) { 
    
  }

  ngOnInit(): void {
  this.totalAmount=0;
    this.displaycart.displayCartItems()
      .subscribe(disCart => this.disCart = disCart);
      console.log("Hii");
     // console.log(this.disCart1);
     //this.user();

  }
  increase(incart:ShopCart) {
    //incart.price=200;
    this.fare=incart.price;
    console.log("dhjkw");
    console.log(this.fare);
   if(incart.quantity >= 1)
   {
    incart.quantity +=1;
   }
   if(incart.quantity == 0)
      {
        incart.quantity=1;
      }
    incart.totalprice=incart.quantity * this.fare;
  
    console.log(incart.quantity);
    console.log(incart);
    this.displaycart.updateCartItems(incart).subscribe(newview => this.shcart=newview);

  }
  decrease(dcart:ShopCart) {
    this.fare=dcart.price;
    if(dcart.quantity >= 1)
    {
      dcart.quantity -=1;
      
    }
    
    
    dcart.totalprice=dcart.quantity * this.fare;
    this.displaycart.updateCartItems(dcart).subscribe(newview => this.shcart=newview );
   
  }
  onCheck(transactuin:Transactions)
  {
    this.transac.transactiontype="NetBanking";
    this.displaycart.checkOutCart(transactuin).subscribe( newview => this.disCart=newview);
  }

  // user()
  // {
  //   this.disCart.buyerid=JSON.stringify(this.disCart.user);
  // }

}
