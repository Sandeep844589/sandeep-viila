import { Component, OnInit } from '@angular/core';
import { Seller } from '../SellerDetails';
import { InventoryService } from '../inventory.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  seller:Seller =new Seller();

  constructor(private sellerdetails:InventoryService, private router: Router) { }

  ngOnInit(): void {
  }
  addSeller()
  {
    this.sellerdetails.addSellers(this.seller).subscribe(seller => this.seller=seller);
    this.router.navigate(['login']);
    alert("You have Successfully registerd");
    
  }
onSubmit()
{

this.addSeller();

}
}
