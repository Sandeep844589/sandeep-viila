package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Category;
import com.example.demo.repositry.CatogeryDao;
import com.example.demo.services.ICatogeryService;



@RestController
@RequestMapping("/category")
public class CatogeryController {
	@Autowired
	private ICatogeryService catogeryserv;
	
  @GetMapping("/getAllCatogeries")
  public List<Category> getAllCatogeries()
   {
	return catogeryserv.getAllCatogeris();
   }



}
