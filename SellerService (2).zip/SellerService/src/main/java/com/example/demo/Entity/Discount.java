package com.example.demo.Entity;



import java.util.Date;

import javax.persistence.*;

@Entity
public class Discount {
	@Id
	private int discount_Id;
	private String discount_code;
	private int percentage;
	@Temporal(TemporalType.TIMESTAMP)
	private Date start_date;
	@Temporal(TemporalType.TIMESTAMP)
	private Date end_date;
	@Temporal(TemporalType.TIMESTAMP)
	private Date description;
	
	
	@Override
	public String toString() {
		return "Discount [discount_Id=" + discount_Id + ", discount_code=" + discount_code + ", percentage="
				+ percentage + ", start_date=" + start_date + ", end_date=" + end_date + ", description=" + description
				+ "]";
	}
	public Discount() {
		System.out.println("Discount Object Has Been Created");
	}
	
	public Discount(int discount_Id, String discount_code, int percentage, Date start_date, Date end_date,
			Date description) {
		super();
		this.discount_Id = discount_Id;
		this.discount_code = discount_code;
		this.percentage = percentage;
		this.start_date = start_date;
		this.end_date = end_date;
		this.description = description;
	}
	public int getDiscount_Id() {
		return discount_Id;
	}
	public void setDiscount_Id(int discount_Id) {
		this.discount_Id = discount_Id;
	}
	public String getDiscount_code() {
		return discount_code;
	}
	public void setDiscount_code(String discount_code) {
		this.discount_code = discount_code;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public Date getEnd_date() {
		return end_date;
	}
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	public Date getDescription() {
		return description;
	}
	public void setDescription(Date description) {
		this.description = description;
	}
	

}
