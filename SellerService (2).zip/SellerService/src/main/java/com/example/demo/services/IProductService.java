package com.example.demo.services;

//import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.ProductDetails;

@Service
public interface IProductService {

	String addProduct(int sellerid, ProductDetails prodetails);

	void deleteProduct(int prodid, int sellerid);

	void updateProduct(ProductDetails pdetails, int sellerid, int prodid);

}
