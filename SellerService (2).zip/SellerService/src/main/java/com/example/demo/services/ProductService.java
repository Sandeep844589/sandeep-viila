package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.ProductDetails;
import com.example.demo.Entity.SellerDetails;
import com.example.demo.repositry.ProductDao;
import com.example.demo.repositry.SellerDao;
@Service
public class ProductService implements IProductService
{
    @Autowired
    private ProductDao productdao;
    @Autowired
    private SellerDao sellerdao;

	@Override
	public String addProduct(int sellerid, ProductDetails prodetails) 
	{     
		SellerDetails sdetails=sellerdao.getOne(sellerid);
		System.out.println(sdetails);
		prodetails.setSdetails(sdetails);
		// TODO Auto-generated method stub
		productdao.save(prodetails);
		return "Product added";
	}

	@Override
	public void deleteProduct(int prodid, int sellerid) {
		productdao.deleteProduct(prodid,sellerid);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateProduct(ProductDetails pdetails, int sellerid, int prodid) {
		ProductDetails productdtails=productdao.getbyid(sellerid, prodid);
		System.out.println(pdetails);
		float cost=pdetails.getPrice();
		int size=pdetails.getQuantity();
		productdtails.setPrice(cost);
		productdtails.setQuantity(size);
		System.out.println(productdtails);
		productdao.save(productdtails);
		
		
	}
     
	
}
