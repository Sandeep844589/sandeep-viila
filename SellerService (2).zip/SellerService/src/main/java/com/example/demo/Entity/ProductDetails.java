package com.example.demo.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class ProductDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productid;
	    private String productName;
		private String Manufacturer;
		private String Model;
		//sellerId: 23
		@ManyToOne
		@JoinColumn(name="sellerid")
		@OnDelete(action = OnDeleteAction.CASCADE)
		private SellerDetails sdetails;
		private float Price;
		private int Quantity;
		@ManyToOne
		@JoinColumn(name="category_id")
		@OnDelete(action = OnDeleteAction.CASCADE)
		private SubCatogery scatogery;
		private String decription;
		//picture: 
		public int getProductid() {
			return productid;
		}
		public void setProductid(int productid) {
			this.productid = productid;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public String getManufacturer() {
			return Manufacturer;
		}
		public void setManufacturer(String manufacturer) {
			Manufacturer = manufacturer;
		}
		public String getModel() {
			return Model;
		}
		public void setModel(String model) {
			Model = model;
		}
		public SellerDetails getSdetails() {
			return sdetails;
		}
		public void setSdetails(SellerDetails sdetails) {
			this.sdetails = sdetails;
		}
		public float getPrice() {
			return Price;
		}
		public void setPrice(float price) {
			Price = price;
		}
		public int getQuantity() {
			return Quantity;
		}
		public void setQuantity(int quantity) {
			Quantity = quantity;
		}
		public SubCatogery getScatogery() {
			return scatogery;
		}
		public void setScatogery(SubCatogery scatogery) {
			this.scatogery = scatogery;
		}
		public String getDecription() {
			return decription;
		}
		public void setDecription(String decription) {
			this.decription = decription;
		}
		public ProductDetails(int productid, String productName, String manufacturer, String model,
				SellerDetails sdetails, float price, int quantity, SubCatogery scatogery, String decription) {
			super();
			this.productid = productid;
			this.productName = productName;
			Manufacturer = manufacturer;
			Model = model;
			this.sdetails = sdetails;
			Price = price;
			Quantity = quantity;
			this.scatogery = scatogery;
			this.decription = decription;
		}
		public ProductDetails() {
			System.out.println("Product Details Object Has been Created");
			
		}
		@Override
		public String toString() {
			return "ProductDetails [productid=" + productid + ", productName=" + productName + ", Manufacturer="
					+ Manufacturer + ", Model=" + Model + ", sdetails=" + sdetails + ", Price=" + Price + ", Quantity="
					+ Quantity + ", scatogery=" + scatogery + ", decription=" + decription + "]";
		}
		

}
