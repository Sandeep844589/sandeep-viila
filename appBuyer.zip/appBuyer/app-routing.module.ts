import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayCartItemsComponent } from './display-cart-items/display-cart-items.component';
import { SearchProductsComponent } from './search-products/search-products.component';
import { SigninComponent } from './signin/signin.component';
import { HomeComponent } from './home/home.component';
import { SignupComponent } from './signup/signup.component';
import { TransactionComponent } from './transaction/transaction.component';
import { PurchaseHistoryComponent } from './purchase-history/purchase-history.component';
import { CategoryComponent } from './category/category.component';


const routes: Routes = [
  {path:'Home/DisplayCart',component: DisplayCartItemsComponent },
  {path:'Home/SearchProducts',component: SearchProductsComponent },
  {path:'Home',component: HomeComponent  },
  {path:'signin',component: SigninComponent },
  {path:'signup',component: SignupComponent },
  {path:'Transaction',component: TransactionComponent },
  {path:'Home/PurchaseHistory',component: PurchaseHistoryComponent },
  {path:'Home/Category',component: CategoryComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
