export class Product
{
  updateProduct() {
    throw new Error("Method not implemented.");
  }
    productid:number;
     productName: String
	 Manufacturer: String
     Model:String
		//sellerId: 23

		sdetails:number;
		 price:number;
		quantity:number;
		
		
	 decription:String;
}