import { Component, OnInit } from '@angular/core';
import { PurchaseHistory } from '../PurchaseHistory';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-purchase-history',
  templateUrl: './purchase-history.component.html',
  styleUrls: ['./purchase-history.component.css']
})
export class PurchaseHistoryComponent implements OnInit {
phistory:PurchaseHistory[];
  constructor(private purchaseHistory:BuyerServiceService) { }

  ngOnInit(): void {
    this.purchaseHistory.getAllHistory() .subscribe(phistory => this.phistory = phistory);

  }

}
