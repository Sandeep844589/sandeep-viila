export class Transactions
{   
    transactionid:number;
    user:number;
    transactiontype:String;
    tatal_price:number;
}