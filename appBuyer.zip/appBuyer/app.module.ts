import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AddcartComponent } from './addcart/addcart.component';
import { DisplayCartItemsComponent } from './display-cart-items/display-cart-items.component';
import { SearchProductsComponent } from './search-products/search-products.component';
import { HomeComponent } from './home/home.component';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { TransactionComponent } from './transaction/transaction.component';
import { PurchaseHistoryComponent } from './purchase-history/purchase-history.component';
import { CategoryComponent } from './category/category.component';
import { TokenInterceptor } from './interceptor';
import { BuyerServiceService } from './buyer-service.service';

@NgModule({
  declarations: [
    AppComponent,
    AddcartComponent,
    DisplayCartItemsComponent,
    SearchProductsComponent,
    HomeComponent,
    SigninComponent,
    SignupComponent,
    TransactionComponent,
    PurchaseHistoryComponent,
    CategoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [BuyerServiceService,{provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
