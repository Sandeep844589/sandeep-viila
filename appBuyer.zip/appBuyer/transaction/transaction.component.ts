import { Component, OnInit, Input } from '@angular/core';
import { Transactions } from '../Transaction';
import { BuyerServiceService } from '../buyer-service.service';
import { Cart, ShopCart } from '../Shoopingcart';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
 
  cart:ShopCart=new ShopCart();
  
  tran:Transactions[];

transaction:Transactions=new Transactions();
  constructor(private transac:BuyerServiceService) { }

  ngOnInit(): void { 
    console.log(this.transaction);
    /*this.transac.getTransations()
    .subscribe(tran => this.tran = tran);*/
   
  }
  onSubmit()
  {console.log(this.transaction.transactiontype);
  this.transac.checkOutCart(this.transaction).subscribe( transaction => this.transaction=transaction);
alert("Your Transaction is ")
  console.log("wdhwh");
//  console.log(this.transaction1);

  }

}
