import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Product } from './Product';
import { Cart } from './Shoopingcart';
import { Transactions } from './Transaction';
import { ApiResponse } from './api.response';
@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  
  private baseUrl="http://localhost:8081/Product/viewAllProducts";
  private baseUrl1="http://localhost:8080/buyer";
  private baseUrl6="http://localhost:8080";
  private baseUrl2="http://localhost:8080/Cart";
  private baseUrl3="http://localhost:8081";
  private baseUrl4="http://localhost:8081/Product"
  constructor(private http:HttpClient ) { }
  getProductByName(productName: String) :Observable<any> {
    return this.http.get(`${this.baseUrl}/${productName}`);
  }
  addCart(cart:object):Observable<any> {
    console.log("ejfhw");
    console.log(cart);  
   return  this.http.post(`${this.baseUrl1}`+`/addCart/1`,cart);
  }
  displayCartItems() :Observable<any>{
    return this.http.get(`${this.baseUrl1}`+`/getcartitems`);
  }
  updateCartItems(incart:Cart):Observable<any> {
    console.log("jfshjsg");
    console.log(incart);
   return this.http.post(`${this.baseUrl1}`+`/updatecart/1`,incart);
  }
  
  
  checkOutCart(transactuin: Object):Observable<any> {
    return this.http.post(`http://localhost:8080/Cart/checkout/1`,transactuin);
  }
  getAllHistory() :Observable<any>{
    return this.http.get(`${this.baseUrl2}/getallHistory`);
  }
  getAllCategories() :Observable<any>{
    return this.http.get(`${this.baseUrl3}/category/getAllCatogeries`);
  }
  getAllProductsByCatogery(category_id: number) :Observable<any>{
    console.log("Ygdwyhg");
    console.log(category_id);
    return this.http.get(`${this.baseUrl3}/Product/viewAllProductsCategory/${category_id}`);
  }
 /* getTransations() :Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }*/
  //updateProductQuantity(prod:Object) :Observable<any>{
    //return this.http.post(`${this.baseUrl3}/updateProduct/{productid}`,prod);
  //}
  updateProductQuantitys(product: Product, productid: number) :Observable<any>{
    return this.http.post(`${this.baseUrl4}/updateProduct/${productid}`,product);
  }
 
  getProduct(productid: number) :Observable<any>{
    return this.http.get(`${this.baseUrl4}/getProductdetails/${productid}`);
  }
  login(loginPayload:object) :Observable<ApiResponse>{
    console.log(loginPayload);
    console.log("in service");
    return this.http.post<ApiResponse>(`${this.baseUrl6}/token/generate-token`,loginPayload);
    
  }
 
  
  
  



}
