package com.example.demo.repositry;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

//import com.example.demo.Buyer;
import com.example.demo.Shoppingcart;


@Repository
public interface CartDao extends JpaRepository<Shoppingcart, Integer> {
	@Query(value="Delete From Shoppingcart sc where sc.productid=:pid")
	public String deleteById(@Param("pid") int productid);
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM Shoppingcart WHERE Shoppingcart.buyerid = :burid"
			,nativeQuery = true)
	public void deleteByItemId(@Param("burid")int burid);
	/*@Transactional
	@Modifying
	@Query(value = "DELETE FROM cart_item WHERE cart_item.buyer_id_fk = :buyerId"
			,nativeQuery = true)
	public void emptyCart(@Param("buyerId")Integer buyerId);
	*/
	@Transactional
	@Modifying
	@Query(value = "SELECT * FROM Shoppingcart WHERE Shoppingcart.buyerid = :buid"
			,nativeQuery = true)
	public List<Shoppingcart> byid(@Param("buid") int buid);
}
