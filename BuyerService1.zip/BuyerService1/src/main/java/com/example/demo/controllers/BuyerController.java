package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Buyer;
import com.example.demo.Product;
import com.example.demo.Shoppingcart;
import com.example.demo.service.BuyerService;

@RestController
@RequestMapping("/buyer")
public class BuyerController {
	@Autowired
	public BuyerService byserv;
	@GetMapping("/getAll")
	public List<Product> getProducts()
	{
		return byserv.getProducts();
	}
	@GetMapping("/gellAllUsers")
	public List<Buyer> getUsers()
	{
		return byserv.getUsers();
	}
	@PostMapping("/createUser")
	public String addProduct(@RequestBody Buyer buyer)
	{
		return byserv.addProduct(buyer);
	}
	@PostMapping("/addCart/{id}")
	public String addCart(@PathVariable("id") int buyerid,@RequestBody Shoppingcart scart)
	{
		return byserv.addCart(buyerid,scart);
	}
	@GetMapping("/getcartitems")
	public List<Shoppingcart> cartItems()
	{
		return byserv.cartItems();
	}
	@DeleteMapping("/Deletecartitem/{id}")
	public String deleteCartItem(@PathVariable("id") int productid)
	{
		return byserv.deleteCartItem(productid);
	}
@PostMapping("/updatecart/{id}/{bid}")
public String updateCart(@PathVariable("id") int cid,@RequestBody Shoppingcart scart1,@PathVariable("bid")int buid)
{
	return byserv.updateCart(cid,scart1,buid);
}
@DeleteMapping("/DeleteAll")
public String deleteAll()
{
	return byserv.deleteAll();
}
}
