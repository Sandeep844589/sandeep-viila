package com.example.demo;

import java.io.Serializable;

import javax.persistence.*;

@Entity
public class Product implements Serializable {
	@Id
	private int  product_id;
	//@OneToOne//categoryId
	//private Category category;
	//@OneToOne//subcategory_id
	//private SubCatogery subcat;
	/*@ManyToOne(cascade = CascadeType.ALL)
	private ShoppingCart cart;*/
	/*public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public SubCatogery getSubcat() {
		return subcat;
	}
	public void setSubcat(SubCatogery subcat) {
		this.subcat = subcat;
	}*/
	public void setStock_number(String stock_number) {
		this.stock_number = stock_number;
	}
	private float price;
	private String product_name;
	private String description;
	private String stock_number;
	private String remarks;
	public Product() {
		System.out.println("Product Object has Been Created");
	}
	
	public Product(int product_id, float price, String product_name,
			String description, String stock_number, String remarks,Shoppingcart cart) {
		super();
		this.product_id = product_id;
		//this.category = category;
		//this.subcat = subcat;
		this.price = price;
		this.product_name = product_name;
		this.description = description;
		this.stock_number = stock_number;
		this.remarks = remarks;
		//this.cart=cart;
	}


	/*public ShoppingCart getCart() {
		return cart;
	}

	public void setCart(ShoppingCart cart) {
		this.cart = cart;
	}
*/
	@Override
	public String toString() {
		return "Product [product_id=" + product_id +  ", price=" + price + ", product_name="
				+ product_name + ", description=" + description + ", stock_number=" + stock_number + ", remarks="
				+ remarks + "]";
	}

	public int getProduct_id() {
		return product_id;
	}
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getStock_number() {
		return stock_number;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	

}
