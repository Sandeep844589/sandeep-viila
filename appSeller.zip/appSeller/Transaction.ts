export class Transactions
{
    user:number;
    transactiontype:String;
    tatal_price:number;
}