import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
//import {ApiService} from "../service/api.service";
//import { InventoryService } from '../inventory.service';
import { Seller } from '../SellerDetails';
import { InventoryService } from '../inventory.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  ngOnInit(): void {
    //throw new Error("Method not implemented.");
  }

  //loginForm: FormGroup;
  //invalidLogin: boolean = false;
  username:string;
  password:string;
  seller:Seller=new Seller();
  constructor( private router: Router,private service: InventoryService) { }

  onSubmit() {
    console.log("in submit method")
    const loginPayload = {
      username: this.username,
      password: this.password
    }
    this.service.login(loginPayload).subscribe(data => {
      debugger;
      if(data.token !== null) {
        console.log("successs");
        window.localStorage.setItem('token', data.result.token);
        this.router.navigate(['Home']);
      }else {
        
        alert(data.message);
      }
    });
   
   

  }
}

  




