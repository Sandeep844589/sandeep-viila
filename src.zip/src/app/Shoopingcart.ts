export class Cart
{
    cart_Id:number;
productid:number;
quantity:number;
price:number;
user:number;
selerid:number;
buyerid:number;
}