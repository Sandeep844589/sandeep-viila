package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.ProductDetails;
import com.example.demo.Entity.SellerDetails;
import com.example.demo.Entity.SubCatogery;
import com.example.demo.repositry.ProductDao;
import com.example.demo.repositry.SellerDao;
import com.example.demo.repositry.SubCatogeryDao;
@Service
public class ProductService implements IProductService
{
    @Autowired
    private ProductDao productdao;
    @Autowired
    private SellerDao sellerdao;
    @Autowired
    private SubCatogeryDao subcatdao;

	@Override
	public ProductDetails addProduct(int sellerid, ProductDetails prodetails,int subcatogeryid) 
	{    SubCatogery subcatogery= subcatdao.getOne(subcatogeryid);
		SellerDetails sdetails=sellerdao.getOne(sellerid);
		System.out.println(sdetails);
		prodetails.setSdetails(sdetails);
		prodetails.setScatogery(subcatogery);
		// TODO Auto-generated method stub
		
		return productdao.save(prodetails);
	}

	@Override
	public void deleteProduct(int prodid, int sellerid) {
		productdao.deleteProduct(prodid,sellerid);
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateProduct(ProductDetails pdetails, int sellerid, int prodid) {
		ProductDetails productdtails=productdao.getbyid(sellerid, prodid);
		System.out.println(pdetails);
		float cost=pdetails.getPrice();
		int size=pdetails.getQuantity();
		productdtails.setPrice(cost);
		productdtails.setQuantity(size);
		System.out.println(productdtails);
		productdao.save(productdtails);
		
		
	}

	@Override
	public List<ProductDetails> viewAllProducts(int sellerid,String productname) {
		// TODO Auto-generated method stub
		return productdao.viewProducts(sellerid,productname);
	}

	@Override
	public Optional<ProductDetails> getProductDetails(int productid) {
		// TODO Auto-generated method stub
		
		return productdao.findById(productid);
	}

	@Override
	public List<ProductDetails> viewAllProductsname(String productname) {
		// TODO Auto-generated method stub
		return productdao.viewProductsname(productname);
	}

	@Override
	public List<ProductDetails> viewAllProductByCategory(int categoryid) {
		// TODO Auto-generated method stub
		System.out.println("Hii"+categoryid);
		return productdao.viewAllProductByCategory(categoryid);
	}

	@Override
	public ProductDetails updateProductQuantity(ProductDetails pdetails, int prodid) {
		ProductDetails item=productdao.getOne(prodid);
		int quantity1=item.getQuantity();
		System.out.println("This is main product"+quantity1);
		int quantity=pdetails.getQuantity();
		System.out.println(quantity);
		item.setQuantity(quantity1-quantity);
		System.out.println(item);
		return productdao.save(item);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ProductDetails> viewAllProductsbyid(int sellerid) {
		// TODO Auto-generated method stub
		return productdao.findAllById(sellerid);
	}
     
	
}
