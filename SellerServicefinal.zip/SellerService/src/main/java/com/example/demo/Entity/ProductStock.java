package com.example.demo.Entity;

public class ProductStock {
	private int stock;

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	@Override
	public String toString() {
		return "ProductStock [stock=" + stock + "]";
	}

	public ProductStock(int stock) {
		super();
		this.stock = stock;
	}
	

}
