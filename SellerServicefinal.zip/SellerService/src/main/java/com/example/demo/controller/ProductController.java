package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.ProductDetails;
import com.example.demo.services.IProductService;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/Product")
public class ProductController
{
	@Autowired
	public IProductService ipservice;
	
	
	
	@PostMapping("/addProduct/{sellerid}/{scatogeryid}")
	public ProductDetails addProduct(@PathVariable("sellerid") int sellerid,@PathVariable("scatogeryid") int subcatogeryid,@RequestBody ProductDetails prodetails)
	{
		return ipservice.addProduct( sellerid,prodetails,subcatogeryid);
	}
    @DeleteMapping("/DeleteItem/{productid}/{sellerid}")
    public String deleteProduct(@PathVariable("productid") int prodid,@PathVariable("sellerid") int sellerid)
    {
    	ipservice.deleteProduct( prodid,sellerid);
	    return "Product Deleted";
    }
    
    @PostMapping("/updateProduct/{seleerid}/{productid}")
    public String updateProduct(@RequestBody ProductDetails pdetails,@PathVariable("seleerid") int sellerid,@PathVariable("productid") int prodid)
    {   
	ipservice.updateProduct( pdetails,sellerid,prodid);
	return "Product Updated";
    }
    @GetMapping("/viewAllProducts/{sellerId}/{productName}")
    public List<ProductDetails> viewAllProducts(@PathVariable("sellerId") int sellerid,@PathVariable("productName") String productname)
    {
	return ipservice.viewAllProducts(sellerid,productname);
    }
    
    
    @GetMapping("/viewAllProductsbyid/{sellerId}")
    public List<ProductDetails> viewAllProductbyid(@PathVariable("sellerId") int sellerid)
    {
	return ipservice.viewAllProductsbyid(sellerid);
    }
    @GetMapping("/getProductdetails/{productid}")
    public Optional<ProductDetails> getProductDetails(@PathVariable("productid") int productid)
    {
    	return ipservice.getProductDetails(productid);
    }
    @GetMapping("/viewAllProducts/{productName}")
    public List<ProductDetails> viewAllProductsname(@PathVariable("productName") String productname)
    {
	return ipservice.viewAllProductsname(productname);
    }
    @GetMapping("/viewAllProductsCategory/{catid}")
    public List<ProductDetails> viewAllProductByCategory(@PathVariable("catid") int categoryid)
    {
    	
    	return ipservice.viewAllProductByCategory(categoryid);
    }
    @PostMapping("/updateProduct/{productid}")
    public ProductDetails updateProductQuantity(@RequestBody ProductDetails pdetails,@PathVariable("productid") int prodid)
    {   
	
	return ipservice.updateProductQuantity( pdetails,prodid);
    }

    
}
