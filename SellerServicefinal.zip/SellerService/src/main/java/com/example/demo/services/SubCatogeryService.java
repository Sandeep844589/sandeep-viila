package com.example.demo.services;

import java.util.List;
//import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Example;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.SubCatogery;
import com.example.demo.repositry.SubCatogeryDao;
@Service
public class SubCatogeryService implements ISubCatogeryService{
@Autowired
private SubCatogeryDao scatdao;
	@Override
	public List<SubCatogery> getAllSubCatogeris() {
		// TODO Auto-generated method stub
		return scatdao.findAll();
	}


}
