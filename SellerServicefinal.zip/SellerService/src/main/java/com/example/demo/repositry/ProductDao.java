package com.example.demo.repositry;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.ProductDetails;
//import com.example.demo.Entity.SellerDetails;

@Repository
public interface ProductDao extends JpaRepository<ProductDetails, Integer>
{    
	
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM product_details  WHERE product_details.sellerid = :sellerid AND product_details.productid=:prodid"
			,nativeQuery = true)
	void deleteProduct(@Param("prodid")int prodid, @Param("sellerid")int sellerid);


     @Query(value="SELECT * FROM product_details WHERE product_details.sellerid = :sellerid AND product_details.productid= :prodid",nativeQuery = true)
     ProductDetails getbyid(@Param("sellerid")int sellerid, @Param("prodid") int prodid);

     @Query(value="SELECT * FROM product_details WHERE product_details.sellerid = :sellerid AND product_details.product_name like :productname%" ,nativeQuery = true)
	List<ProductDetails> viewProducts(@Param("sellerid") int sellerid, @Param("productname") String productname);
   //  @Query(value="SELECT * FROM product_details WHERE  product_details.product_name like :productname%" ,nativeQuery = true)
//@Query(value="SELECT * FROM  product_details.product_name like :productname%" ,nativeQuery = true)

     @Query(value="FROM ProductDetails WHERE  lower(productName) like %:productname%")
	List<ProductDetails> viewProductsname(@Param("productname")String productname);

     @Query(value="SELECT * FROM product_details WHERE  product_details.category_id= :categoryid",nativeQuery = true)
	List<ProductDetails> viewAllProductByCategory(@Param("categoryid")int categoryid);

     @Query(value="SELECT * FROM product_details WHERE  product_details.sellerid= :selleri",nativeQuery = true)
	List<ProductDetails> findAllById(@Param("selleri")int sellerid);
     
    

}
