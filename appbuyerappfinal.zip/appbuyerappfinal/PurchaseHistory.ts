export class PurchaseHistory
{
    purchaseid:number;
	//Buyer_id
	//Seller_id
	//Transaction_id
	//Item_id
	
    user_buyerid:number;
number_of_items:number;
	
 date_time:Date;
 productprice:Number;
}