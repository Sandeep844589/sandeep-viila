import { Component, OnInit } from '@angular/core';
import { Buyer } from '../Buyer';
import { Router } from '@angular/router';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  username:string;
  password:string;
  buyer:Buyer=new Buyer();
  constructor(private router:Router,private loginservice:BuyerServiceService) { }

  ngOnInit(): void {
  }
  onSubmit() {
    console.log("in submit method")
    const loginPayload = {
      username: this.username,
      password: this.password
    }
    this.loginservice.login(loginPayload).subscribe(data => {
      debugger;
      if(data.result.token !== null) {
        console.log("successs");
        window.localStorage.setItem('token', data.result.token);
        window.localStorage.setItem('username', data.result.username);
        window.localStorage.setItem('password', data.result.password);
        window.localStorage.setItem('buyerid', data.result.buyerid);
        console.log(window.localStorage.getItem('token'));
        
        this.router.navigate(['Home']);
      }else {
        
        alert(data.message);
      }
    });
   
   

  }

}
