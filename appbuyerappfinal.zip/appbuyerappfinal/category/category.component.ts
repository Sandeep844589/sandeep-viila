import { Component, OnInit } from '@angular/core';
import { Category } from '../Category';
import { BuyerServiceService } from '../buyer-service.service';
import { Product } from '../Product';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  category:Category[];
  product:Product[];
  
  constructor(private cate:BuyerServiceService) { }

 
  ngOnInit(): void {
    this.cate.getAllCategories()
    .subscribe(category => this.category = category);
   
  }
  onSubmit(cat:Category)
  {
    console.log(cat.category_id);
    console.log(cat.category_name);
    this.cate.getAllProductsByCatogery(cat.category_id)
    .subscribe(product => this.product = product);
  }

}
