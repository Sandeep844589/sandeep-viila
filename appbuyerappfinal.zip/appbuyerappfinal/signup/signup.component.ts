import { Component, OnInit } from '@angular/core';
import { Buyer } from '../Buyer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
buyer:Buyer=new Buyer();
  sellerdetails: any;
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  addBuyer()
  {
    this.sellerdetails.addSellers(this.buyer).subscribe(buyer => this.buyer=buyer);
    this.router.navigate(['signin']);
    alert("You have Successfully registerd");
    
  }
onSubmit()
{

this.addBuyer();

}
}
