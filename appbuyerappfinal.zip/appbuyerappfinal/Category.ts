 export class Category
 {
     category_id:number;
    category_name:String;
   brief_details:String;
}
 