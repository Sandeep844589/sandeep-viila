export class Cart
{
    cart_Id:number;
productid:number;
quantity:number;
price:number;
user:number;
selerid:number;
buyerid:number;
}
export class ShopCart
{
    cart_Id:number;
productid:number;
quantity:number;
price:number;
totalprice:number;
user:number;
selerid:number;
buyerid:number;
}