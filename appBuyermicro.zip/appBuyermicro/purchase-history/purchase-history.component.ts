import { Component, OnInit } from '@angular/core';
import { PurchaseHistory } from '../PurchaseHistory';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-purchase-history',
  templateUrl: './purchase-history.component.html',
  styleUrls: ['./purchase-history.component.css']
})
export class PurchaseHistoryComponent implements OnInit {
  buyerid:any;
phistory:PurchaseHistory[];
  constructor(private purchaseHistory:BuyerServiceService) { }

  ngOnInit(): void {
    this.buyerid=window.localStorage.getItem('buyerid');
    this.purchaseHistory.getAllHistory(this.buyerid) .subscribe(phistory => this.phistory = phistory);

  }

}
