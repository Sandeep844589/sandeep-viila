import { Component, OnInit, Input } from '@angular/core';
import { BuyerServiceService } from '../buyer-service.service';
import { Cart, ShopCart } from '../Shoopingcart';
import { Transactions } from '../Transaction';
import { Router } from '@angular/router';
import { Product } from '../Product';

@Component({
  selector: 'app-display-cart-items',
  templateUrl: './display-cart-items.component.html',
  styleUrls: ['./display-cart-items.component.css']
})
export class DisplayCartItemsComponent implements OnInit {
  disCart:ShopCart[];
  shcart:ShopCart =new ShopCart();
  fare:number;
  totalAmount:number;
 product:Product=new Product();
  transaction1:Transactions=new Transactions();
  transact:Transactions[];
  constructor(private displaycart:BuyerServiceService,private router:Router)
     { 
    
  }

  ngOnInit(): void {
  this.totalAmount=0;
    this.displaycart.displayCartItems()
      .subscribe(disCart => this.disCart = disCart);
      console.log("Hii");
     // console.log(this.disCart1);
     //this.user();

  }
  
  increase(incart:ShopCart) {
 
    //incart.price=200;
    this.fare=incart.price;
    
    console.log("dhjkw");
    console.log(this.fare);
  
    this.displaycart.getProduct(incart.productid)
      .subscribe(product => this.product = product);
      console.log("This is the quantity from Inventory");
      console.log(this.product.quantity);
      if(incart.quantity < this.product.quantity)
      {
        if(incart.quantity >= 1)
   {
    incart.quantity +=1;
   }
   if(incart.quantity == 0)
      {
        incart.quantity=1;
      }
      }
   
    incart.totalprice=incart.quantity * this.fare;
    this.product.quantity=incart.quantity;
    console.log("This is Product Id");
    console.log(incart.productid);
    console.log(this.product.quantity); 
    this.displaycart.updateProductQuantitys(this.product,incart.productid)
      .subscribe(product => this.product = product);
  
    console.log(incart.quantity);
    console.log(incart);
    this.displaycart.updateCartItems(incart).subscribe(newview => this.shcart=newview);
    console.log("This is the quantity from Inventory after");
    console.log(this.product.quantity);
  }
  decrease(dcart:ShopCart) {
    this.fare=dcart.price;

    this.displaycart.getProduct(dcart.productid)
    .subscribe(product => this.product = product);
    console.log("This is the quantity from Inventory");
    console.log(this.product.quantity);

    if(dcart.quantity < this.product.quantity)
    {
      if(dcart.quantity >= 1)
    {
      dcart.quantity -=1;
      
    }
    }
    
    this.product.quantity=dcart.quantity;
    console.log("This is Product Id");
    console.log(dcart.productid);
    console.log(this.product.quantity); 
    this.displaycart.updateProductQuantitys(this.product,dcart.productid)
      .subscribe(product => this.product = product);
  
    console.log(dcart.quantity);
    console.log(dcart);
    
    dcart.totalprice=dcart.quantity * this.fare;
    this.displaycart.updateCartItems(dcart).subscribe(newview => this.shcart=newview );
   
  }
  onCheck()
  {
    //this.transaction1.transactiontype="NetBanking";
    //this.displaycart.checkOutCart(this.transaction1).subscribe( transaction1 => this.transaction1=transaction1);

    console.log("wdhwh");
  //  console.log(this.transaction1);
   this.router.navigate(['Transaction']);
  }

  // user()
  // {
  //   this.disCart.buyerid=JSON.stringify(this.disCart.user);
  // }

}
