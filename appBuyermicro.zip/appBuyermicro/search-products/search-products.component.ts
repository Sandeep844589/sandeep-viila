import { Component, OnInit } from '@angular/core';
import { Product } from '../Product';
import { BuyerServiceService } from '../buyer-service.service';

@Component({
  selector: 'app-search-products',
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent implements OnInit {
  productName:String;
  product: Product[];
  constructor(private dataService:BuyerServiceService) { }

  ngOnInit(): void {
    this.productName="";
  }
  private searchProducts() {
    this.dataService.getProductByName(this.productName)
    .subscribe(product => this.product = product);
  }

  onSubmit() {
    this.searchProducts();
  }

}
