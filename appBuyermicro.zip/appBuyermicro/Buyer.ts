export class Buyer
{
   // buyerid:number;
   buyerid:number;
	username:String;
	 password:String;
	emailid:String;
 mobile_number:number;
}