import { Component, OnInit } from '@angular/core';
import { InventoryService } from '../inventory.service';
import { Product } from '../Product';

@Component({
  selector: 'app-updateproduct',
  templateUrl: './updateproduct.component.html',
  styleUrls: ['./updateproduct.component.css']
})
export class UpdateproductComponent implements OnInit {

  upproduct:Product=new Product();
  constructor(private update:InventoryService) { }

  ngOnInit(): void {
  }
  addItem()
  {
    alert("Product Added SucessFully");
    this.update.updateProduct1(this.upproduct,this.upproduct.productName).subscribe(upproduct => this.upproduct=upproduct);
  }
  onSubmit()
  {
this.addItem();
  }


}
