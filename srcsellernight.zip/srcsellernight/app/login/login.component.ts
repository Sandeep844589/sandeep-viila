import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
//import {ApiService} from "../service/api.service";
//import { InventoryService } from '../inventory.service';
import { Seller } from '../SellerDetails';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  ngOnInit(): void {
    //throw new Error("Method not implemented.");
  }

  //loginForm: FormGroup;
  //invalidLogin: boolean = false;
  username:string;
  password:string;
  seller:Seller=new Seller();
  constructor( private router: Router) { }

  onSubmit() {
    console.log(this.seller.username);
    console.log(this.seller.password);
   
      if(this.seller.username=="SandeepVilla" && this.seller.password=="Sandy1998")
      {
        alert("You have Successfully registerd"+" Hii"+" "+this.seller.username);
        this.router.navigate(['Home']);
      }
    }
   
  }

  




