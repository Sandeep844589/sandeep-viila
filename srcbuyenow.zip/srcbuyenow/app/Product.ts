export class Product
{
     productid:number;
	     productName:String
         manufacturer:String
		 model:String
		//sellerId: 23
	
	 sdetails:number;
     price:number;
		quantity:number;
		
		scatogery:number;
	decription:String;
}