import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DeleteItemComponent } from './delete-item/delete-item.component';
import { AddNewItemComponent } from './add-new-item/add-new-item.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'Home', component: HomeComponent },
  {path:'AddItem',component:AddNewItemComponent},
  {path:'DeleteItemById',component:DeleteItemComponent},
  {path:'Home/SignUp',component:SignUpComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
