export class Seller
{
    username:String;
    password:String;
    emailid:String;
    mobile_number:number;
}