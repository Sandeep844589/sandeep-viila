import { Injectable } from '@angular/core';
import { Product } from './Product';
import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http'
import { Seller } from './SellerDetails';
//import {ApiResponse} from "../model/api.response";
@Injectable({
  providedIn: 'root'
})
export class InventoryService {
 
  
private baseUrl="http://localhost:8081/Product"
  constructor(private http : HttpClient) { }
  addProduct(product: Product)  :Observable<any>{
   return this.http.post(`${this.baseUrl}/addProduct/1/1`,product);
  }
  deleteItems(productid: number) :Observable<any>{
    return this.http.delete(`${this.baseUrl}/DeleteItem/${productid}/1`,{responseType:'text'});
  }
  addSellers(seller: Seller) :Observable<any> {
    return this.http.post(`${this.baseUrl}/createUser`,seller);
  }
  
  
}
