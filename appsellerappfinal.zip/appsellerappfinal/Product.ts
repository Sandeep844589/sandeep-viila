export class Product
{
     productid:number;
	     productName:String
         manufacturer:String
		 model:String
		//sellerId: 23
	catogeryname:String;
	 sdetails:number;
     price:number;
		quantity:number;
		
		scatogery:number;
	decription:String;
}