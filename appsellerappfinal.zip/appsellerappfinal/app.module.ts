import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddNewItemComponent } from './add-new-item/add-new-item.component';
import { DeleteItemComponent } from './delete-item/delete-item.component';
import { FormsModule } from '@angular/forms';
//import { ReactiveFormsModule } from "@angular/forms";
import { SignUpComponent } from './sign-up/sign-up.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { UpdateproductComponent } from './updateproduct/updateproduct.component';
import { InventaryComponent } from './inventary/inventary.component';
import { InventoryService } from './inventory.service';
import { TokenInterceptor } from './interceptor';
import { LogOutComponent } from './log-out/log-out.component';


@NgModule({
  declarations: [
    AppComponent,
    AddNewItemComponent,
    DeleteItemComponent,
    SignUpComponent,
    HomeComponent,
    LoginComponent,
    UpdateproductComponent,
    InventaryComponent,
    LogOutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
 
  ],
  providers: [InventoryService,{provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
