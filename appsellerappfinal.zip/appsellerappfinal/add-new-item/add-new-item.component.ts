import { Component, OnInit } from '@angular/core';
import { Product } from '../Product';
import { InventoryService } from '../inventory.service';
import { Category } from '../Category';

@Component({
  selector: 'app-add-new-item',
  templateUrl: './add-new-item.component.html',
  styleUrls: ['./add-new-item.component.css']
})
export class AddNewItemComponent implements OnInit {
  category:Category[];
  catid:number;
  catog:Category=new Category();
product:Product=new Product();
sellerid:any;
  constructor(private inventory:InventoryService) { }

  ngOnInit(): void {
    this.inventory.getAllCategories()
    .subscribe(category => this.category = category);
  }
  onadd(cat:Category)
  {
    this.catid= cat.category_id;
    this.catog.category_name=cat.category_name;
    console.log(this.catog.category_name);
  }

  addItem()
  {
    this.sellerid=window.localStorage.getItem('sellerid');
    //this.product.scatogery=this.catid
    console.log(this.product.scatogery)
    alert("Product Added SucessFully");
    this.inventory.addProduct(this.product,this.catid, this.sellerid).subscribe(product => this.product=product);
  }
  onSubmit()
  {
this.addItem();
  }

}
