import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DeleteItemComponent } from './delete-item/delete-item.component';
import { AddNewItemComponent } from './add-new-item/add-new-item.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { UpdateproductComponent } from './updateproduct/updateproduct.component';
import { InventaryComponent } from './inventary/inventary.component';
import { LogOutComponent } from './log-out/log-out.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'Home', component: HomeComponent },
  {path:'Home/AddItem',component:AddNewItemComponent},
  {path:'Home/DeleteItemById',component:DeleteItemComponent},
  {path:'SignUp',component:SignUpComponent},
  {path:'Home/Home/updateproduct',component:UpdateproductComponent},
  {path:'Home/Home/inventory',component:InventaryComponent},
  {path:'logout',component:LogOutComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
