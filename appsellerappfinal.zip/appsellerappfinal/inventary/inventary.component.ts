import { Component, OnInit } from '@angular/core';
import { Product } from '../Product';
import { InventoryService } from '../inventory.service';

@Component({
  selector: 'app-inventary',
  templateUrl: './inventary.component.html',
  styleUrls: ['./inventary.component.css']
})
export class InventaryComponent implements OnInit {
  product: Product[];
  sellerid:any;
  constructor(private inventor:InventoryService) { }
  
  ngOnInit(): void {
    this.sellerid=window.localStorage.getItem('sellerid');
    console.log(this.sellerid);
     this.inventor.getProductBysellerid(this.sellerid)
    .subscribe(product => this.product = product);
  }
  onSubmit(it:Product)
  {
    this.sellerid=window.localStorage.getItem('sellerid');
console.log(it.productid);
this.inventor.deleteproduct(it.productid,this.sellerid).subscribe(product => this.product = product);
alert("item is deleted");
  }

}
