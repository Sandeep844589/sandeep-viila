import { Injectable } from '@angular/core';
import { Product } from './Product';
import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http'
import { Seller } from './SellerDetails';
import { ApiResponse } from './api.response';
//import { ApiResponse } from './api.response';
//import {ApiResponse} from "../model/api.response";
@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  
private baseUrl="http://localhost:8081"
 
private baseurl15="http://localhost:8989/mentorportal/SellerServices";
  constructor(private http : HttpClient) { }
  addProduct(product: Product,cartid :number,sellerid:any)  :Observable<any>{
    console.log("Inservice addproduct cartid");
    console.log(cartid);
   return this.http.post(`${this.baseUrl}/Product/addProduct/${sellerid}/${cartid}`,product);
  }
  deleteItems(productid: number) :Observable<any>{
    return this.http.delete(`${this.baseUrl}/DeleteItem/${productid}/1`,{responseType:'text'});
  }
  addSellers(seller: Seller) :Observable<any> {
    console.log(seller);
    return this.http.post(`${this.baseUrl}/seller/createseller`,seller);
  }
  
  updateProduct(upproduct: Product) :Observable<any> {
    return this.http.post(`${this.baseUrl}/Product/updateProduct/1/26`,upproduct);
  }
  updateProduct1(upproduct: Product, productName: String):Observable<any> {
    return this.http.post(`${this.baseUrl}/Product/updateProduct/1/${productName}`,upproduct);
  }
  getAllCategories() :Observable<any>{
    return this.http.get(`${this.baseUrl}/category/getAllCatogeries`);
  }
  login(loginPayload:object) :Observable<ApiResponse>{
    console.log(loginPayload);
    console.log("in service");
    return this.http.post<ApiResponse>(`${this.baseUrl}/token/generate-token`,loginPayload);
    
  }
  getProductBysellerid(sellerid: any):Observable<any> {
    return this.http.get(`${this.baseurl15}/Product/viewAllProductsbyid/${sellerid}`);
  }
 
  deleteproduct(productid: number, sellerid: any) :Observable<any>{
    return this.http.delete(`${this.baseurl15}/Product/DeleteItem/${productid}/${sellerid}`);
  }
  
 
  
}
