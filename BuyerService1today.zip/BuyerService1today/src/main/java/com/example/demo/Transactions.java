package com.example.demo;



import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;

//import org.hibernate.annotations.ManyToAny;

@Entity
public class Transactions {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionid;
	/*@ManyToOne//user_id
	private Buyer user;*/
	//seller_id
	@ManyToOne
	private Buyer user;
	
	private String transactiontype;//(Eg. debit or credit)
	@CreationTimestamp
	@Temporal(TemporalType.DATE)
	private Date date_time;

	private float tatal_price;
	public Transactions()
	{
		System.out.println("Transation Object has been created");
	}

	
    

	public Transactions(int transactionid, Buyer user, String transactiontype, Date date_time, float price,
			float tatal_price) {
		super();
		this.transactionid = transactionid;
		this.user = user;
		this.transactiontype = transactiontype;
		this.date_time = date_time;

		this.tatal_price = tatal_price;
	}




	public Buyer getUser() {
		return user;
	}

   public void setUser(Buyer user) {
		this.user = user;
	}
   
    public float getTatal_price() {
	return tatal_price;
}


public void setTatal_price(float tatal_price) {
	this.tatal_price = tatal_price;
}


	











	@Override
public String toString() {
	return "Transactions [transactionid=" + transactionid + ", user=" + user + ", transactiontype=" + transactiontype
			+ ", date_time=" + date_time + ",  tatal_price=" + tatal_price + "]";
}




	public int getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(int transactionid) {
		this.transactionid = transactionid;
	}
	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
    public Date getDate_time() {
		return date_time;
	}

	public void setDate_time(Date date_time) {
		this.date_time = date_time;
	}
	
	

}
