package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.example.demo.Buyer;
import com.example.demo.Shoppingcart;
//import com.example.demo.Transactions;
//import com.example.demo.Entity.Product;
//import com.example.demo.repositry.BuyerDao;
import com.example.demo.repositry.CartDao;
import com.example.demo.repositry.UserDao;

@Service
public class BuyerService {
	//@Autowired
	//public BuyerDao bydao;
	@Autowired
	public UserDao usdao;
	@Autowired
	public CartDao cdao;

	/*public List<Product> getProducts()
	{
		
		return  bydao.findAll();
	}
*/
	public Buyer addProduct(Buyer buyer) {
		// TODO Auto-generated method stub
		 
		return usdao.save( buyer); 
	}

	public List<Buyer> getUsers() {
		// TODO Auto-generated method stub
		return usdao.findAll();
	}

	public String addCart(int buyerid, Shoppingcart scart) {
		Buyer br =usdao.getOne(buyerid);
		System.out.println(br);
		scart.setUser(br);
		// TODO Auto-generated method stub
		System.out.println(scart);
		cdao.save(scart);
		return "\" Item Added To Cart\" ";
	}

	public List<Shoppingcart> cartItems() {
		// TODO Auto-generated method stub
		return cdao.findAll();
	}

	public String deleteCartItem(Integer productid) {
		// TODO Auto-generated method stub
		 cdao.deleteBypId(productid);
		return "\"item deleted in the cart\" ";
	}

	public Shoppingcart updateCart(Shoppingcart scart1,int buid) 
	{
		Buyer br1=usdao.getOne(buid);
		Shoppingcart sr=cdao.getOne(scart1.getCart_Id());
		//int cartid=scart1.getCart_Id();
		int prid=scart1.getProductid();
		int quantity=scart1.getQuantity();
		float price=scart1.getPrice();
		float toatlprice=scart1.getTotalprice();
		//sr.setCart_Id(cartid);
		sr.setProductid(prid);
		sr.setQuantity(quantity);
		sr.setPrice(price);
		sr.setTotalprice(toatlprice);
		sr.setUser(br1);
		System.out.println(sr);
		
		return cdao.save(sr);
	}

	public String deleteAll() {
		cdao.deleteAll();
		return "\"Caert Items Deleted\"";
	}

	
	

}
