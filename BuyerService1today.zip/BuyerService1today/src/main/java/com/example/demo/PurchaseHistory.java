package com.example.demo;



import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;

@Entity
public class PurchaseHistory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int purchaseid;
	//Buyer_id
	//Seller_id
	//Transaction_id
	//Item_id
	@ManyToOne
	private Buyer user;
	private int Number_of_items;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date Date_time;
	private float productprice;
	public float getProductprice() {
		return productprice;
	}




	public void setProductprice(float productprice) {
		this.productprice = productprice;
	}




	public PurchaseHistory() {
		System.out.println("Purchase Histoty Object Has been created");
	}
	
	

	
	public Buyer getUser() {
		return user;
	}




	public void setUser(Buyer user) {
		this.user = user;
	}









	public PurchaseHistory(int purchase_Id, Buyer user, int number_of_items, Date date_time, float productprice) {
		super();
		this.purchaseid = purchase_Id;
		this.user = user;
		Number_of_items = number_of_items;
		Date_time = date_time;
		this.productprice = productprice;
	}






	@Override
	public String toString() {
		return "PurchaseHistory [purchase_Id=" + purchaseid + ", user=" + user + ", Number_of_items=" + Number_of_items
				+ ", Date_time=" + Date_time + ", productprice=" + productprice + "]";
	}




	public int getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	public int getNumber_of_items() {
		return Number_of_items;
	}
	public void setNumber_of_items(int number_of_items) {
		Number_of_items = number_of_items;
	}

	public Date getDate_time() {
		return Date_time;
	}

	public void setDate_time(Date date_time) {
		Date_time = date_time;
	}
	
	

}
