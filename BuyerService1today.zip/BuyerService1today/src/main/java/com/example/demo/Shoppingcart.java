package com.example.demo;

//import java.io.Serializable;
//import java.util.List;

import javax.persistence.*;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
//import org.springframework.stereotype.Repository;

@Entity
public class Shoppingcart{
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int cart_Id;

private  int productid;
public int getProductid() {
	return productid;
}


public void setProductid(int productid) {
	this.productid = productid;
}
private int selerid;
public int getSelerid() {
	return selerid;
}


public void setSelerid(int selerid) {
	this.selerid = selerid;
}


public float getPrice() {
	return price;
}


public void setPrice(float price) {
	this.price = price;
}
private int quantity;
private float price;
private float totalprice;

@ManyToOne
@JoinColumn(name="buyerid")
@OnDelete(action = OnDeleteAction.CASCADE)
private Buyer user;

public int getQuantity() {
	return quantity;
}


public void setQuantity(int quantity) {
	this.quantity = quantity;
}


public Buyer getUser() {
	return user;
}


public void setUser(Buyer user) {
	this.user = user;
}


//productId
public Shoppingcart() {
	System.out.println("ShoppingCart Object Has been Created");
}





public Shoppingcart(int cart_Id, int productid, int selerid, int quantity, float price, float totalprice, Buyer user) {
	super();
	this.cart_Id = cart_Id;
	this.productid = productid;
	this.selerid = selerid;
	this.quantity = quantity;
	this.price = price;
	this.totalprice = totalprice;
	this.user = user;
}





public float getTotalprice() {
	return totalprice;
}


public void setTotalprice(float totalprice) {
	this.totalprice = totalprice;
}


@Override
public String toString() {
	return "Shoppingcart [cart_Id=" + cart_Id + ", productid=" + productid + ", selerid=" + selerid + ", quantity="
			+ quantity + ", price=" + price + ", totalprice=" + totalprice + ", user=" + user + "]";
}


public int getCart_Id() {
	return cart_Id;
}

public void setCart_Id(int cart_Id) {
	this.cart_Id = cart_Id;
}



}
