package com.example.demo.service;

import java.util.List;

//import java.util.Date;
//import java.util.List;

//import javax.persistence.Temporal;
//import javax.persistence.TemporalType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Buyer;
import com.example.demo.PurchaseHistory;
import com.example.demo.Shoppingcart;
import com.example.demo.Transactions;
//import com.example.demo.repositry.BuyerDao;
import com.example.demo.repositry.CartDao;
import com.example.demo.repositry.PurchaseHistoryDao;
import com.example.demo.repositry.TransactionDao;
import com.example.demo.repositry.UserDao;

@Service
public class CartService {
	/*@Autowired
	public BuyerDao bydao;*/
	@Autowired
	public UserDao usdao;
	@Autowired
	public CartDao cdao;
	@Autowired
	public TransactionDao tdao;
	@Autowired
	public PurchaseHistoryDao pdao;
	
	public String checkOut(Transactions transac, int buid) {
		Buyer buyr=usdao.getOne(buid);
		System.out.println(buyr);
		transac.setUser(buyr);
		System.out.println(transac);
		float sum=0;
		
		//PurchaseHistory phistory=new PurchaseHistory();
		//Shoppingcart shcartitems=new Shoppingcart();
		List<Shoppingcart> shcart1=cdao.byid(buid);
		for(int i=0;i<shcart1.size();i++)
		{
			PurchaseHistory phistory=new PurchaseHistory();
			Shoppingcart shcartitems=shcart1.get(i);
			int size=shcartitems.getQuantity();
			float cost=shcartitems.getPrice();
			
			//phistory.setPurchase_Id(i);
			phistory.setNumber_of_items(size);
			phistory.setUser(buyr);
			phistory.setProductprice(cost);
			System.out.println(shcartitems);
			System.out.println(shcartitems.getCart_Id());
			
			cdao.deleteById(shcartitems.getCart_Id());
			pdao.save(phistory);
			//float sum=0;
			sum=cost+sum;
			//sum1=sum;
		}
		transac.setTatal_price(sum);
		
		tdao.save(transac);
		// TODO Auto-generated method stub
		return "Transaction SuccesFull";
	}

	public void deleteByItemId(int burid) {
		
		 cdao.deleteByItemId(burid);
	}

	public String addPurchase(PurchaseHistory phis) {
		// TODO Auto-generated method stub
		return null;
	}

}
