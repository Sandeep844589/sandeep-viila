import { Component } from '@angular/core';
import { BuyerServiceService } from './buyer-service.service';
import { Product } from './Product';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  productName:String;
  product: Product[];
  title = 'BuyerPart';

  constructor(private dataService:BuyerServiceService) { }
  ngOnInit(){
    this.productName="";
  } 
    private searchProducts() {
      this.dataService.getProductByName(this.productName)
      .subscribe(product => this.product = product);
    }
  
    onSubmit() {
      this.searchProducts();
    }
}
