import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Product } from './Product';
@Injectable({
  providedIn: 'root'
})
export class BuyerServiceService {
  
  private baseUrl="http://localhost:8081/Product/viewAllProducts";
  private baseUrl1="http://localhost:8080/buyer/addCart/1";
  constructor(private http:HttpClient ) { }
  getProductByName(productName: String) :Observable<any> {
    return this.http.get(`${this.baseUrl}/${productName}`);
  }
  addCart(cart:object):Observable<any> {
    console.log("ejfhw");
    console.log(cart);
   return  this.http.post(`${this.baseUrl1}`,cart);
  }
  
 

  
}
