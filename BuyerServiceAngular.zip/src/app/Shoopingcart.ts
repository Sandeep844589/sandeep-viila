export class Cart
{
productid:number;
quantity:number;
price:number;
selerid:number;
}